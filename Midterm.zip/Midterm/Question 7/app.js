import { sayHello } from "./greeting.js";

sayHello("Andrew", (result) => {
  console.log(result);
});
