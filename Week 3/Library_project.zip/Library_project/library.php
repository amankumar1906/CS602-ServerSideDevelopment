<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Abstract Class - Item
abstract class Item {
    protected $ID;
    protected $title;

    public function __construct($ID, $title) {
        $this->ID = $ID;
        $this->title = $title;
    }

    public function getID() {
        return $this->ID;
    }

    abstract public function getDescription();
}

// Book Class
class Book extends Item {
    private $author;
    private $ISBN;
    private $status;

    public function __construct($ID, $title, $author, $ISBN) {
        parent::__construct($ID, $title);
        $this->author = $author;
        $this->ISBN = $ISBN;
        $this->status = "available";
    }

    public function getDescription() {
        return "{$this->title} by {$this->author} (Status: {$this->status})";
    }

    public function checkOut() {
        $this->status = "checked out";
    }

    public function getAuthor() {
        return $this->author;
    }

    public function getISBN() {
        return $this->ISBN;
    }

    public function getStatus() {
        return $this->status;
    }
}

// Library Class
class Library {
    private $items = [];

    public function addItem(Item $item) {
        $this->items[$item->getID()] = $item;
    }

    public function removeItem($ID) {
        unset($this->items[$ID]);
    }

    public function getAllItems() {
        return $this->items;
    }
}

// Helper function to print the contents of the library
function printLibraryContents(Library $library) {
    $items = $library->getAllItems();
    if (empty($items)) {
        echo "Library is empty.<br>";
    } else {
        echo "<table border='1'>";
        echo "<tr><th>ID</th><th>Title</th><th>Author</th><th>ISBN</th><th>Status</th></tr>";
        foreach ($items as $item) {
            if($item instanceof Book) {
                echo "<tr>";
                echo "<td>" . $item->getID() . "</td>";
                echo "<td>" . $item->getDescription() . "</td>";
                echo "<td>" . $item->getAuthor() . "</td>"; 
                echo "<td>" . $item->getISBN() . "</td>"; 
                echo "<td>" . $item->getStatus() . "</td>"; 
                echo "</tr>";
            }
        }
        echo "</table>";
    }
    echo "<hr>";
}


// Functional Tests
function testLibraryFunctions() {
    $library = new Library();

    // Initial state
    printLibraryContents($library);

    // Adding books
    $book1 = new Book(1, "Merchant of Venice", "Shakespeare", "5354125987");
    $book2 = new Book(2, "The Alchemist", "Paulo Coelho", "7462848283");
    $library->addItem($book1);
    $library->addItem($book2);
    printLibraryContents($library);

    // Removing a book
    $library->removeItem(1);
    printLibraryContents($library);

    // Checking out a book
    $book2->checkOut();
    printLibraryContents($library);
}

// Run the tests
testLibraryFunctions();

?>
