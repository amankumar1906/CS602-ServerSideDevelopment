export const breadChoices = {
    'Wheat': 0.50,
    'White': 0.00,
    'Pita': 1.00
};

export const meatChoices = {
    'Roast Beef': 2.50,
    'Ham': 1.75,
    'Turkey': 2.00,
    'Tuna': 3.00
};

export const cheeseChoices = {
    'Swiss': 1.25,
    'American': 0.50,
    'Cheddar': 2.25
};

export const toppingChoices = {
    'Tomato': 0.25,
    'Pickles': 0.25,
    'Onions': 0.25,
    'Mushrooms': 0.25,
    'Hot Chili\'s': 0.25,
    'Green Peppers': 0.25,
    'Olives': 0.25
};